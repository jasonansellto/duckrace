//Save this file for future use. We may need to take another look
//at it to get user images working. 

// import React from 'react';
// import { Card, Image } from 'semantic-ui-react';
// import '../Profile.css';

// const UserImageCard = ({ imageUrl }) => {
//   return (
//     // Add the image-card class to the Card component
//     <Card className="image-card">
    
//       <Image src={imageUrl} ui={false} />
      
//     </Card>
//   );
// };

// export default UserImageCard;

